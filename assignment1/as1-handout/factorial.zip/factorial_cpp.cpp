/**
   Programmer: Karim Naqvi
   Project: Sample of using cerr and cout in C++.
   Date: 2012-9-10

   Description: This is a sample, intended to help students with
   assignment 1, which shows how one can write to cerr and cout
   appropriately.
 */

#include <iostream>  
#include <string>
#include <cstdlib>
#include <sstream>

/**
   Precondition: n >= 0.
 */
int factorial(int n)
{
    if (n == 0)
        return 1;
    return n*factorial(n-1);
}

void usage(std::string progname)
{
    using namespace std;
    cerr << "Factorial Table Generator\n";
    cerr << "Usage: " << progname << "  maxnum\n";
    cerr << "  where maxnum is the largest factorial to be printed in the table.\n";
    exit(1);
}

int main(int argc, char ** argv)
{
    int const MAX_FACTORIAL_ARG = 13;

    if (argc != 2)
	usage(argv[0]);
    std::istringstream ss(argv[1]);
    int n = 0;
    ss >> n;
    if (!ss) {
	std::cerr << "error converting provided value: " << argv[1] << '\n';
	exit(1);
    }
    
    // number conversion must have worked!
    if (n > MAX_FACTORIAL_ARG) {
	std::cerr << "Maximum permitted factorial argument is " << MAX_FACTORIAL_ARG << '\n';
	exit(1);
    }
    if (n < 0) {
	std::cerr << "Minimum permitted factorial argument is 0\n";
	exit(1);
    }
    
    std::cout << "n\tn!\n"
	"---------\n";
    for (int i = 0; i <= n; ++i) {
	std::cout << i << '\t' << factorial(i) << '\n';
    }
    return 0;
}
