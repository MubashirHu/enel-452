/**
   Programmer: Karim Naqvi
   Project: Sample of using stderr and stdout in C.
   Date: 2012-9-10

   Description: This is a sample, intended to help students with
   assignment 1, which shows how one can write to stderr and stdout
   appropriately.
 */

#include <stdio.h>  // fprintf()
#include <stdlib.h> // exit()
#include <errno.h>  // errno
#include <string.h> // strerror()

int factorial(int n)
{
    if (n == 0)
        return 1;
    return n*factorial(n-1);
}

void usage(char const *progname)
{
    fprintf(stderr, "Factorial Table Generator\n");
    fprintf(stderr, "Usage: %s maxnum\n", progname);
    fprintf(stderr, "  where maxnum is the largest factorial to be printed in the table.\n");
    exit(1);
}

#define MAX_FACTORIAL_ARG 13

int main(int argc, char ** argv)
{
    if (argc != 2)
	usage(argv[0]);
    char *p = 0;
    errno = 0;			// detect any errors in errno
    long n = strtol(argv[1], &p, 10);
    if (errno != 0) {
	fprintf(stderr, "error: %s\n", strerror(errno));
	exit(1);
    }
    // number conversion must have worked!
    if (n > MAX_FACTORIAL_ARG) {
	fprintf(stderr, "Maximum permitted factorial argument is %d\n", MAX_FACTORIAL_ARG);
	exit(1);
    }
    if (n < 0) {
	fprintf(stderr, "Minimum permitted factorial argument is 0\n");
	exit(1);
    }
    
    fprintf(stdout, "n\tn!\n"
	    "---------\n");
    for (int i = 0; i <= n; ++i) {
        fprintf(stdout, "%d\t%d\n", i, factorial(i));
    }
    return 0;
}
