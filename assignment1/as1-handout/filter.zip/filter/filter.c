/**
   This example is meant to help students with the Complex Calculator
   assignment of enel452.

   All UNIX programs (and their descendants) start with three open
   files which they can immediately use with no need to manage them:

   0: an input file, named 'stdin'.  This is normally attached to
      the terminal in which the process is running.  Think: the keyboard.

   1: an output file, named 'stdout'.  This is normally attached to
      the terminal in which the process is running.  Think: the screen.

   2: an output file, named 'stderr'.  This is normally also attached
      to the terminal in which the process is running (so, the screen).

   However it's possible to *redirect* any or all of these so they
   refer instead to devices, or actual files in a file system.  This
   can be done from the command-line using the '<' and '>' characters.
 */


#include <stdio.h>
#include <ctype.h>

int main() {
    int c = 0;
    while ((c = getc(stdin)) != EOF) {
        if (c=='a') c = 'A';
        fputc(c, stdout);
    }
}
